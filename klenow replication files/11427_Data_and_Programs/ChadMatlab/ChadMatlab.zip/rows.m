function i=rows(data);
% Returns the number of rows of data
i=size(data,1);