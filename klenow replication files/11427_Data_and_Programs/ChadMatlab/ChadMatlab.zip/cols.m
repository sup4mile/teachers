function i=cols(data);
% Returns number of columns in data
i=size(data,2);