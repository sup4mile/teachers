% minnan.m     y=minnan(x);
%
% Returns min(packr(x))

function y=minnan(x);

y=min(packr(x));