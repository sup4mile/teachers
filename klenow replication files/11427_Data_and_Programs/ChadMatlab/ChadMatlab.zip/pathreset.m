% pathreset.m    6/3/09
%
% Resets the path to drop off all of my special paths
% Use when creating replication archive to be sure no special
% files are being used that aren't available to others.

rmpath /home/chad/Work/procs
rmpath /home/chad/Work/Data/Maddison
rmpath /home/chad/Work/Data
rmpath /home/chad/Work/Data/PWT90
rmpath /home/chad/Work/Data/PWT80
%rmpath /home/chad/Work/Rawls
%rmpath /home/chad/Work/Book/SecondEdition/Data
%rmpath /home/chad/Work/Data/PWT63
%rmpath /home/chad/Work/Data/PWT62
%rmpath /home/chad/Work/Data/PWT61
%rmpath /home/chad/Work/Data/PWT56
%rmpath /home/chad/Work/Data/BarroLee
%rmpath /home/chad/Work/Data/BarroLee2000
rmpath /home/chad/Work/Data/Jorgenson
%rmpath /home/chad/Documents/MATLAB
rmpath /home/chad/matlab

path