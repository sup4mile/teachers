% maxnan.m     y=maxnan(x);
%
% Returns max(packr(x))

function y=maxnan(x);

y=max(packr(x));