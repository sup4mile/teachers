% definecolors: myblue, mygreen, myred

myblue=[        0    0.4470    0.7410];
mygreen=[    0.4660    0.64    0.1880];
myred=[    0.8500    0.3250    0.0980];
mygrey=[210 210 210]/255;
myorng=[237 145 33]/255;
myblack=[0 0 0];
%mypurp=[186 85 211]/255;
mypurp=[125 38 205]/255;
darkfactor=0.8;
LW=4; % default LineWidth

mycolors=[myblue; mygreen; mypurp; myred; myorng; mygrey; myblack];
